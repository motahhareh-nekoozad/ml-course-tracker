
export const courseData = [
  { week: 1, day: "Monday", date: "2025-10-20", title: "Introduction", exercise: "Discuss key ideas together" },
  { week: 1, day: "Tuesday", date: "2025-10-21", title: "Supervised Learning", exercise: "Implement small dataset example" },
  { week: 1, day: "Wednesday", date: "2025-10-22", title: "Linear Regression (1 variable)", exercise: "Collaboratively implement linear regression" },
  { week: 1, day: "Thursday", date: "2025-10-23", title: "Linear Regression (Multiple variables)", exercise: "Try dataset with multiple features" },
  { week: 1, day: "Friday", date: "2025-10-24", title: "Gradient Descent", exercise: "Test different learning rates" }
];
