
import React, { useState } from "react";
import { courseData } from "./data/courseData";
import VideoList from "./components/VideoList";
import CalendarView from "./components/CalendarView";

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const userIds = ["user1", "user2"];

  return (
    <div className={darkMode ? "dark" : ""}>
      <div className="min-h-screen p-6 bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-white">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-3xl font-bold">ML Course Tracker</h1>
          <button className="px-4 py-2 bg-blue-500 text-white rounded" onClick={() => setDarkMode(!darkMode)}>
            {darkMode ? "Light Mode" : "Dark Mode"}
          </button>
        </div>
        <CalendarView events={courseData} />
        <VideoList videos={courseData} userIds={userIds} />
      </div>
    </div>
  );
}

export default App;
