
import React from "react";
import { Calendar, dateFnsLocalizer } from "react-big-calendar";
import { format, parse, startOfWeek, getDay } from "date-fns";
import "react-big-calendar/lib/css/react-big-calendar.css";

const locales = { "en-US": require("date-fns/locale/en-US") };
const localizer = dateFnsLocalizer({ format, parse, startOfWeek, getDay, locales });

function CalendarView({ events }) {
  const formattedEvents = events.map(e => ({ title: e.title, start: new Date(e.date), end: new Date(e.date) }));
  return <div className="my-6"><Calendar localizer={localizer} events={formattedEvents} startAccessor="start" endAccessor="end" style={{ height: 500 }} /></div>;
}

export default CalendarView;
