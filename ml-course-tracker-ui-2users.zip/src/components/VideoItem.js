
import React from "react";

function VideoItem({ video, userStatuses }) {
  return (
    <div className="p-4 border rounded-lg mb-2 shadow bg-white dark:bg-gray-800">
      <div className="flex justify-between items-center">
        <div>
          <span className="font-bold text-lg">{video.title}</span>
          <p className="text-sm mt-1">{video.day} | {video.exercise}</p>
        </div>
        <div className="flex space-x-2">
          {Object.keys(userStatuses).map((userId) => (
            <div key={userId}
                 className={`w-6 h-6 rounded-full border-2 border-gray-500 ${
                   userStatuses[userId] ? (userId === "user1" ? "bg-purple-500" : "bg-yellow-400") : "bg-white"
                 }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default VideoItem;
