
import React, { useEffect, useState } from "react";
import VideoItem from "./VideoItem";
import { db } from "../firebase";
import { doc, getDoc } from "firebase/firestore";

function VideoList({ videos, userIds }) {
  const [statuses, setStatuses] = useState({});

  useEffect(() => {
    const fetchStatuses = async () => {
      const allStatuses = {};
      for (let video of videos) {
        allStatuses[video.title] = {};
        for (let userId of userIds) {
          const docRef = doc(db, "progress", `${userId}_${video.title}`);
          const docSnap = await getDoc(docRef);
          allStatuses[video.title][userId] = docSnap.exists() ? docSnap.data().done : false;
        }
      }
      setStatuses(allStatuses);
    };
    fetchStatuses();
  }, [videos, userIds]);

  return (
    <div className="mt-4">
      {videos.map((v) => (
        <VideoItem key={v.title} video={v} userStatuses={statuses[v.title] || {}} />
      ))}
    </div>
  );
}

export default VideoList;
